# 加入我们

你好，你想加入我们吗？如果你想的话，我们随时恭候

!!! tip "我们的联系方式"

    WhiteNX分支作者(`此分支作者`)：<whitenxserver@outlook.com>

    主线分支作者：踪天朔 <ts@ar-cdn.top>

    Ar-Sr-Na分支作者：<root@arsrna.cn>

    我们的QQ群号：`1097347557`

**我们非常感谢你的加入**
