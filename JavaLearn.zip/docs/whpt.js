var domain = window.location.host;
if ( domain != "java.eyling.top" && domain != "127.0.0.1"){
    window.location.href=“https://java.eyling.top”;
}