# 更新日志

| 日期      | 描述                          |
| ----------- | ------------------------------------ |
| `2020/6/30`       | :material-check:     完成变量章节  |
| `2021/1/31`       | :material-check-all: 全面切换至暗色调，删除冗余，更改邮箱，更新后端版本，支持中文搜索 |
| `2021/1/31` | :material-check: 上传完整文件到Github |
| `-`    | :material-close:     等待主线更新 |
| `2021/1/31` | :material-check: 完成"Java娘的基本数据类型"章节 |
| `2021/2/1` | :material-check-all: 修复部分Markdown语法错误，修改错字 |
| `2021/2/2` | :material-check: 新增"循环酱们！"章节 |
| `2021/2/3` | :material-check: 新增"Java娘的浮点运算"章节 |
| `2021/3/6` | :material-check-all: 解决了部分文章Markdown的语法问题，修改了错误 |
| `2021/4/3` | :material-check-all: 新增“Java娘的输入”章节 |