# WhiteNX JavaLearn Project 帮助中心

欢迎来到本帮助中心，此页面用于帮助用户解决一些常规问题。

!!! tip "我能来这里做什么？"

    这里是在文档内的任何问题以及解决方案的集合点，您如果在查看教程时发现了错误，可以前往此页面寻找。

!!! warning "这里不是万能的"

    您的错误很可能不是常规错误，这里也没有给出解决方案，您可以前往`baidu.com`或`bing.com`查询解决方案。

!!! failure "本页面尚未完善，无法履行它的职责"

!!! question "如何提问题？"

    您可以前往[Github](https://github.com/White-NX/Javalearn-issuesreport/issues/new "此网页")提交issues.
    